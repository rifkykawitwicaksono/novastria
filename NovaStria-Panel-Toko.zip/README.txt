NOVASTRIA PANEL — PAKET WEBSITE PEMESANAN MANUAL

ISI:
- index.html: halaman toko
- assets/style.css: desain responsif
- assets/app.js: paket/harga dan formulir order

CARA MENJALANKAN:
1. Ekstrak ZIP.
2. Buka index.html untuk tes lokal di browser.
3. Untuk online gratis: unggah isi folder (index.html dan folder assets) ke repository GitHub, aktifkan Settings > Pages > Deploy from a branch > main > /(root).
4. Alternatifnya unggah file-file ini ke hosting web yang kamu miliki.
5. Ubah harga di assets/app.js pada nilai `price` masing-masing paket.
6. Formulir menghasilkan file ringkasan pesanan .txt dan menawarkan membuka WhatsApp admin setelah kamu memasukkan nomor WhatsApp admin.
7. Isi nomor WhatsApp admin yang benar ketika diminta. Tidak ada nomor kontak yang ditebak.

PENTING:
- Ini frontend statis. Formulir tidak menyimpan pesanan ke database dan tidak memverifikasi pembayaran otomatis.
- Jangan menerima bukti pembayaran hanya dari screenshot tanpa memeriksa mutasi/riwayat transaksi.
- Harga dalam paket merupakan harga usulan, bukan harga modal yang sudah diverifikasi. Sesuaikan sebelum dipublikasikan.
- Pastikan durasi paket, CPU, disk, lokasi, dan dukungan software dikonfirmasi sebelum pembayaran.
- Paket Unlimited bukan berarti resource fisik benar-benar tanpa batas.
- Jangan publikasikan password, API key, atau kredensial admin Pterodactyl.
- Paket Reseller/ADP hanya boleh dijual bila penyedia memberi hak dan fasilitas tersebut.
